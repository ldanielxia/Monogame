﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using System.Collections.Generic;

namespace XiaLi_ShipGame
{
    public class CollisionManager : GameComponent
    {
        private List<Ball> balls;
        private Ship ship;
       // private ScoreString scoreString;
        private SoundEffect hitSound;
        private Explosion explosion;
        private Game _game = null;
        private TimerString timerString1;
        private ScoreString scoreString;
        public CollisionManager(Game game,
            List<Ball> balls,
            Ship ship,
            Explosion explosion,
           // ScoreString scoreString,
            SoundEffect hitSound,TimerString timerString,ScoreString scoreString) : base(game)
        {
            this.balls = balls;
            this.ship = ship;
            this._game=game;
           // this.scoreString = scoreString;
            this.hitSound = hitSound;
            this.explosion = explosion;
            this.timerString1 = timerString;
            this.scoreString = scoreString; 
        }

        public override void Update(GameTime gameTime)
        {
          
            Rectangle ShipRect = ship.getBounds();
            //
            // Rectangle rectangle1 = new Rectangle((int)(ship.Position.X), (int)(ship.Position.Y), ShipRect.Width, 1);
            for (int i = 0; i<balls.Count; i++)
            {
                Rectangle ballRect = balls[i].getBounds();
                 Rectangle rectangle1 = new Rectangle((int)(ship.Position.X) , (int)(ship.Position.Y), ShipRect.Width/4, ShipRect.Height/4);
                //Rectangle shipRect = ship.getBounds();
                if (ballRect.Intersects(rectangle1))
                {                    
                    Vector2 position = new Vector2(ship.Position.X, ship.Position.Y);
                    explosion.Position = position;
                    explosion.restart();

                    timerString1.ITime=0;
                    scoreString.Score=0;

                    ship.Position= new Vector2(-600, -600);
                  
                    hitSound.Play();
                    break;
                }
            }


            base.Update(gameTime);
        }
    }
}
