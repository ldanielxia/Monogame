﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace XiaLi_ShipGame
{
    public class Ship : DrawableGameComponent
    {
        private SpriteBatch spriteBatch;
        private Texture2D tex;
        private Vector2 position;
        private Vector2 speed;
        private float rotation = 0f;
        private Rectangle srcRect;
        private Vector2 origin;
        private Vector2 stage;

        private float scale = 0.4f;
        private int scaleNumber = 4;
        public Vector2 Position { get => position; set => position = value; }
        public float Scale { get => scale; set => scale = value; }
        public Texture2D Tex { get => tex; set => tex = value; }

        public Ship(Game game, SpriteBatch spriteBatch,
            Texture2D tex,
            Vector2 position,
            Vector2 speed,
            Vector2 stage) : base(game)
        {
            this.spriteBatch = spriteBatch;
            this.tex = tex;
            this.position = position;
            this.speed = speed;
            this.stage = stage;
            srcRect = new Rectangle(0, 0, tex.Width, tex.Height);
            origin = new Vector2(tex.Width / 2, tex.Height / 2);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            //v 6
            spriteBatch.Draw(tex, position, srcRect, Color.Green, rotation, origin, scale,
                SpriteEffects.None, 0);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            if (this.Enabled)
            {
                MouseState ms = Mouse.GetState();

                if (ms.LeftButton == ButtonState.Pressed)
                {
                    Vector2 target = new Vector2(ms.X, ms.Y);
                    float xDiff = target.X - position.X;
                    float yDiff = target.Y - position.Y;

                    //translation
                    position.X += xDiff * speed.X * 0.05f;
                    position.Y += yDiff * speed.Y * 0.05f;

                    //top wall
                    if (position.Y <= tex.Height / scaleNumber)
                    {
                        position.Y = tex.Height / scaleNumber;
                    }
                    //left wall
                    if (position.X <=tex.Height / scaleNumber)
                    {
                        position.X = tex.Height / scaleNumber;
                    }
                    //righ wall
                    if (position.X >= stage.X - (tex.Width / scaleNumber))
                    {
                        position.X = stage.X - (tex.Width /scaleNumber);
                    }
                    //down wall
                    if (position.Y >= stage.Y-tex.Height/scaleNumber)
                    {
                        position.Y = stage.Y-tex.Height/scaleNumber;
                    }
                    //rotation
                    float deviation = 0;
                    if (xDiff < 0)
                    {
                        deviation = (float)Math.PI;
                    }
                    rotation = deviation + (float)Math.Atan(yDiff / xDiff);
                }

            }

            base.Update(gameTime);
        }
        public Rectangle getBounds()
        {
            return new Rectangle((int)position.X, (int)position.Y, tex.Width / 2, tex.Height / 2);
        }
    }
}
