﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XiaLi_ShipGame
{
    public class LevelString : SimpleString
    {
        //private double delay;
        //private double delayCounter;
        private bool flag = true;
        private int _level;

        public int iLevel{ get => _level; set => _level = value; }

        public LevelString(Game game,
            SpriteBatch spriteBatch,
            SpriteFont font,
            string message,
            Vector2 position,
            Color color,
             int _level) : base(game, spriteBatch, font, message, position, color)
        {
           
            this.Enabled = false;
            this._level = _level;
        }

        public override void Draw(GameTime gameTime)
        {
            if (flag)
            {
                spriteBatch.Begin();
                spriteBatch.DrawString(font, this.iLevel.ToString() + "  ", position, color);
                spriteBatch.End();
            }
        }

        public override void Update(GameTime gameTime)
        {
            //if (this.Enabled)
            //{
            //    delayCounter += gameTime.ElapsedGameTime.TotalSeconds;
            //    if (delayCounter >= delay)
            //    {
            //        delayCounter = 0;
            //        this.Enabled = false;
            //    }
            //}

            base.Update(gameTime);
        }
    }
}
