﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XiaLi_ShipGame
{
    public class TimerString : SimpleString
    {
        private bool isDraw = true;
        private int iTimer = 30;

        public int ITime { get => iTimer; set => iTimer = value; }

        public TimerString(Game game,
            SpriteBatch spriteBatch,
            SpriteFont font,
            string message,
            Vector2 position,
            Color color,
            int _iTime) : base(game, spriteBatch, font, message, position, color)
        {

            this.iTimer = _iTime;
        }

        public override void Draw(GameTime gameTime)
        {
            if (isDraw)
            {
                spriteBatch.Begin();
                spriteBatch.DrawString(font, "0:" + this.ITime.ToString().PadLeft(2, '0') + " Sec", position, color);
                spriteBatch.End();
            }
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }
    }
}
