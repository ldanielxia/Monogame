﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace XiaLi_ShipGame
{
    public class Ball : DrawableGameComponent
    {
        private SpriteBatch spriteBatch;
        private Texture2D tex;
        private Vector2 position;
        private Vector2 speed;
        private Vector2 stage;
        private SoundEffect hitSound, missSound;
        private double delayCounter;
        private double delay = 0.2f;

        public Vector2 Speed { get => speed; set => speed = value; }
        public Vector2 Position { get => position; set => position = value; }

        public Ball(Game game,
            SpriteBatch spriteBatch,
            Texture2D tex,
            Vector2 position,
            Vector2 speed,
            Vector2 stage,
            SoundEffect hitSound,
            SoundEffect missSound) : base(game)
        {
            this.spriteBatch = spriteBatch;
            this.tex = tex;
            this.position = position;
            this.speed = speed;
            this.stage = stage;
            this.hitSound = hitSound;
            this.missSound = missSound;
            //this.Enabled = false;
            //this.Visible = false;
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(tex, position, Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            //speed.X=getWidthNext(stage.X);
            if (this.Enabled)
            {
                delayCounter += gameTime.ElapsedGameTime.TotalSeconds;
                if (delayCounter >= delay)
                {
                    //ball move action
                   // speed.X =- getWidthNext(15.0f);
                    //speed.Y = -getWidthNext(5.0f);
                    position += speed;
                    delayCounter = 0;
                }
               // position = speed;

                //top wall
                if (position.Y <= 0)
                {
                    speed.Y = -speed.Y;
                    //hitSound.Play();
                }
                //righ wall
                if (position.X >= stage.X - tex.Width / 2)
                {
                    speed.X = -speed.X;
                    // hitSound.Play();
                }
                //down wall
                if (position.Y >= stage.Y - tex.Height/4 )
                {
                    //missSound.Play();
                    //this.Enabled = false;
                    //this.Visible = false;
                    this.position = new Vector2(100, 100);
                }
                //left wall
                if (position.X <= 0)
                {
                    position.X = stage.X-tex.Width;
                    // hitSound.Play();
                }
            }
            base.Update(gameTime);
        }

        public void RndBall()
        {
            speed.X = getWidthNext(stage.X);
            speed.Y = getWidthNext(stage.Y);
        }

        public Rectangle getBounds()
        {
            return new Rectangle((int)position.X, (int)position.Y, tex.Width, tex.Height);
        }

        public float getWidthNext(float width)
        {
            Random rd = new Random();
            int i = rd.Next(0, (int)Math.Floor(width));
            return i;
        }

    }
}
