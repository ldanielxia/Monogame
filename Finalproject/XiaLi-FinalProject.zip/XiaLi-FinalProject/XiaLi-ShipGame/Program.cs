﻿
using var game = new XiaLi_ShipGame.Game1();
game.Run();
