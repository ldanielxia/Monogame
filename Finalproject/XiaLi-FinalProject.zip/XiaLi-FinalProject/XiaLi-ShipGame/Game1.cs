﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System;
using System.Collections.Generic;
using System.Text;

namespace XiaLi_ShipGame
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private SpriteFont font1;
        private SpriteFont font2;
        SimpleString levelLabel;
        SimpleString timeLabel;
        SimpleString scoreLabel;
        SimpleString usernameLabel;
        SimpleString usernameString;
        TimerString timeString;
        SimpleString gameTips;
        ScoreString scoreString;
        LevelString levelString;
        private int Times = 30;  
        private bool flag = false;
        private bool flagNext = false;
        private double controlSec = 1.0;
        private double controlParseSec = 3.0;  //Set the pause time of each close
        private double delayCounter, delayCount2;
        private Ship ship;
        private Texture2D shipTex;
        private Texture2D texExplosion;
        private Explosion explosion;
        private List<Ball> balls = new List<Ball>();
        private bool _isGameEnd = false;
        private int Score = 1;
        private int iLevel = 1;
        private string username="XiaLi5936851|";
        System.Text.StringBuilder sb = new StringBuilder();
        public bool isGameEnd { get => _isGameEnd; set => _isGameEnd = value; }

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            //Background---------------------------------------------------------------------

            Vector2 stage3 = new Vector2(_graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
            Texture2D tex = this.Content.Load<Texture2D>("images/background");

            Rectangle srcRect = new Rectangle(0, 0, tex.Width, tex.Height); ;
            Vector2 pos = new Vector2(0, stage3.Y - srcRect.Height);
            Vector2 speed2 = new Vector2(2, 0);
            ScrollingBackground sb = new ScrollingBackground(this, _spriteBatch, tex, pos, srcRect, speed2);

             this.Components.Add(sb);
            //-----------------------------------------------------------------
            //backgroup Music
            //-----------------------------------------------------------------
            Song backgroundMusic = this.Content.Load<Song>("sound/backgroupsong");
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(backgroundMusic);
            //-----------------------------------------------------------------
            //song
            SoundEffect dingSound = this.Content.Load<SoundEffect>("sound/ding");
            SoundEffect applause = this.Content.Load<SoundEffect>("sound/applause1");
            SoundEffect clickSound = this.Content.Load<SoundEffect>("sound/click");
            //-----------------------------------------------------------------
            // font
            //-----------------------------------------------------------------
            font1 = this.Content.Load<SpriteFont>("fonts/Font1");
            font2 = this.Content.Load<SpriteFont>("fonts/Font2");
            //
            levelLabel = new SimpleString(this, _spriteBatch, font1, "LEVELS: ", new Vector2(10, 10), Color.White);
            timeLabel = new SimpleString(this, _spriteBatch, font1, "TIMER: ", new Vector2(10, 30), Color.White);
            scoreLabel = new SimpleString(this, _spriteBatch, font1, "LIFE: ", new Vector2(10, 60), Color.White);
            usernameLabel= new SimpleString(this, _spriteBatch, font1, "USER: ", new Vector2(200, 10), Color.White);
            usernameString= new SimpleString(this, _spriteBatch, font1, username+getSpeedNext(10, 99), new Vector2(250, 10), Color.White);
            this.Components.Add(levelLabel);
            this.Components.Add(timeLabel);
            this.Components.Add(scoreLabel);
            this.Components.Add(usernameLabel);
            this.Components.Add(usernameString);
            //levelString = new LevelString(this, _spriteBatch, font1, "", new Vector2(80, 10), Color.Red, iLevel, iLevel);
            levelString = new LevelString(this, _spriteBatch, font1, "", new Vector2(80, 10), Color.Red,iLevel);
            this.Components.Add(levelString);
            timeString = new TimerString(this, _spriteBatch, font1, "", new Vector2(80, 30), Color.Red, Times);
            this.Components.Add(timeString);
            // scoreString = new ScoreString(this, _spriteBatch, font1, "", new Vector2(80, 60), Color.Red, 1, Score);
            scoreString = new ScoreString(this, _spriteBatch, font1, "", new Vector2(80, 60), Color.Red, Score);
            this.Components.Add(scoreString);

            //Game Tips 
            gameTips = new SimpleString(this, _spriteBatch, font2, "Game Begin,Click Enter Key to Begin. ", new Vector2(_graphics.PreferredBackBufferWidth / 2 - 200, _graphics.PreferredBackBufferHeight / 2 - 30), Color.Red);
            this.Components.Add(gameTips);

            /////////////////////
            shipTex = Content.Load<Texture2D>("images/Ship");
            Vector2 stage1 = new Vector2(_graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
            Vector2 position = new Vector2(60, stage1.Y / 2);
            Vector2 speed = new Vector2(1, 1);
            ship = new Ship(this, _spriteBatch, shipTex, position, speed, stage1);
            this.Components.Add(ship);

            /////-----------------------------------------------------------------
            ///Six Ball 
            /////-----------------------------------------------------------------
            Texture2D ballTex = this.Content.Load<Texture2D>("images/Ball");
            Vector2 stage = new Vector2(_graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
            //ball first postion 
            Vector2 ballSpeed = new Vector2(-getSpeedNext(3, 8), 0);
            Vector2 ballPos = new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6-30);

            Ball ball1 = new Ball(this, _spriteBatch, ballTex, ballPos, ballSpeed, stage, dingSound, applause);
            this.Components.Add(ball1);
            // different postion 
            ballSpeed = new Vector2(-getSpeedNext(3, 8), 0);
            Vector2 ballPos2 = new Vector2(_graphics.PreferredBackBufferWidth-350, _graphics.PreferredBackBufferHeight/6*2);
            Ball ball2 = new Ball(this, _spriteBatch, ballTex, ballPos2, ballSpeed, stage, dingSound, applause);
            this.Components.Add(ball2);

            //Vector2 ballPos3 = new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6*3);
            ballSpeed = new Vector2(-getSpeedNext(3, 8), 0);
            Vector2 ballPos3 = new Vector2(_graphics.PreferredBackBufferWidth-550, _graphics.PreferredBackBufferHeight/6*3);
            Ball ball3 = new Ball(this, _spriteBatch, ballTex, ballPos3, ballSpeed, stage, dingSound, applause);
            this.Components.Add(ball3);

            ballSpeed = new Vector2(-getSpeedNext(3, 8), 0);
            Vector2 ballPos4 = new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6*4);
            Ball ball4 = new Ball(this, _spriteBatch, ballTex, ballPos4, ballSpeed, stage, dingSound, applause);
            this.Components.Add(ball4);

            ballSpeed = new Vector2(-getSpeedNext(3, 8), 0);
            Vector2 ballPos5 = new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6*5);
            Ball ball5 = new Ball(this, _spriteBatch, ballTex, ballPos5, ballSpeed, stage, dingSound, applause);
            this.Components.Add(ball5);

            ballSpeed = new Vector2(-getSpeedNext(3, 8), 0);
            Vector2 ballPos6 = new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6*6+30);
            Ball ball6 = new Ball(this, _spriteBatch, ballTex, ballPos6, ballSpeed, stage, dingSound, applause);
            this.Components.Add(ball6);
            balls=new List<Ball>();
            balls.Add(ball1);
            balls.Add(ball2);
            balls.Add(ball3);
            balls.Add(ball4);
            balls.Add(ball5);
            balls.Add(ball6);
            foreach (Ball b in balls)
            {
                b.Enabled=false;
                b.Visible=false;
            }
            /////-----------------------------------------------------------------
            /////********Explosion*****************/
            /////-----------------------------------------------------------------

            texExplosion = this.Content.Load<Texture2D>("images/explosion");
            explosion = new Explosion(this, _spriteBatch, texExplosion, Vector2.Zero, 3);
            this.Components.Add(explosion);
            /////-----------------------------------------------------------------
            ////Collision Manager
            ////-----------------------------------------------------------------
            CollisionManager cm = new CollisionManager(this, balls, ship, explosion, clickSound, timeString, scoreString);
            this.Components.Add(cm);

        }
  
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            //KeyboardState state = Keyboard.GetState();
            //foreach (var key in state.GetPressedKeys())
            //{
            //    if (!Keyboard.GetState().IsKeyDown(Keys.Enter))
            //    {
            //        sb.Append(""+key);
            //    }
            //}
            //if (sb.Length > 0)
            //    System.Diagnostics.Debug.WriteLine(sb.ToString());
            // TODO: Add your update logic here
            if (Keyboard.GetState().IsKeyDown(Keys.Enter))
            {
                //if (sb.Length > 0)
                //{
                // this.username=sb.ToString();
                // usernameString.Message=this.username;
                // }
                usernameString= new SimpleString(this, _spriteBatch, font1, username+getSpeedNext(10, 99), new Vector2(250, 10), Color.White);
                flag = true;
                //reset the game
                Times=30;
                timeString.ITime=Times;
                timeString.Enabled = true;
                Score=1;
                scoreString.Score=Score;

                gameTips.Visible = false;
                gameTips.Message = "";
                //ship
                Vector2 stage1 = new Vector2(_graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);
                Vector2 position = new Vector2(60, stage1.Y / 2);
                ship.Position = position;
                ship.Enabled=true;
                ship.Visible=true;
                //ball 
                initBall();
                levelString.iLevel=1;

            }
            if (flag&& timeString.ITime>0)
            {
                delayCounter += gameTime.ElapsedGameTime.TotalSeconds;
                if (delayCounter >= controlSec)
                {
                    delayCounter = 0;
                    Times -= 1;
                    timeString.ITime = Times;
                   
                    if (Times == 0)
                    {
                        flag = false;
                    }
                }
            }
            //game over
            if (timeString.ITime==0)
            {
                flag = false;
                gameTips.Visible = true;

                //
                if (levelString.iLevel==3)
                {
                    Vector2 tempPos = new Vector2(_graphics.PreferredBackBufferWidth / 2 - 200, _graphics.PreferredBackBufferHeight / 2 - 30);
                    gameTips.Position=tempPos;
                    if (scoreString.Score>0)
                    {
                        gameTips.Message = "GAME OVER, YOU WIN. ";
                    }
                    else
                    {
                         tempPos = new Vector2(_graphics.PreferredBackBufferWidth / 2 - 200, _graphics.PreferredBackBufferHeight / 2 - 30);
                        gameTips.Position=tempPos;
                        gameTips.Message="GAME OVER ,BETTER TRY NEXT TIME.";
                    }
                    //ball not move 
                    foreach (Ball b in balls)
                    {
                        b.Enabled=false;
                    }
                    //ship not move
                    ship.Enabled=false;
                }
                else
                {
                    if (scoreString.Score>0)
                    {
                        flagNext=false;
                     
                        flag = true;
                       
                        //first stop 
                        ship.Enabled=false;
                        foreach (Ball b in balls)
                        {
                            b.Enabled=false;
                        }

                        //show level infomation
                        gameTips.Message=" GAME LEVEL "+(levelString.iLevel+1);
                       Vector2 tempPos= new Vector2(_graphics.PreferredBackBufferWidth/2-100, _graphics.PreferredBackBufferHeight/2-30);
                        gameTips.Position=tempPos;
                        gameTips.Visible=true;
                        //为了上面通关之后提示的停留时间
                        if (!flagNext)
                        {
                            //Set the pause time of each close
                            this.delayCount2 += gameTime.ElapsedGameTime.TotalSeconds;
                            if (delayCount2>=this.controlParseSec)
                            {
                                delayCount2 = 0;
                                
                                flagNext = true;//让下一步能进行

                                gameTips.Visible=false;

                                Times=30;
                                timeString.ITime=30;

                                iLevel+=1;
                                levelString.iLevel=iLevel;

                            }
                        }
                        //pause time is out
                        if (flagNext) {
                            ship.Enabled=true;
                            //speed fast
                            if (iLevel==2)
                            {                              
                                foreach (Ball b in balls)
                                {
                                    b.Enabled =true;
                                    //change the ball's speed
                                    Vector2 ballSpeed = new Vector2(-getSpeedNext(25, 60), 0);
                                    b.Speed=ballSpeed;
                                }
                                flagNext=false;
                            }
                            else if (iLevel==3)
                            {
                                foreach (Ball b in balls)
                                {
                                    //change the ball's speed
                                    Vector2 ballSpeed = new Vector2(-getSpeedNext(45, 150), 0);
                                    b.Speed=ballSpeed;
                                    b.Enabled=true;
                                }
                            }
                        }
                    }
                    else
                    {
                        iLevel=1;
                        Vector2 tempPos = new Vector2(_graphics.PreferredBackBufferWidth / 2 - 200, _graphics.PreferredBackBufferHeight / 2 - 30);
                        gameTips.Position=tempPos;
                        gameTips.Message="GAME OVER ,BETTER TRY NEXT TIME.";
                        //ball not move 
                        foreach (Ball b in balls)
                        {
                            b.Enabled=false;
                        }
                        //ship not move
                        ship.Enabled=false;
                    }
                }
            }
            base.Update(gameTime);
        }

        private void initBall()
        {
            for (int i = 0; i<balls.Count; i++)
            {
                Vector2 ballSpeed = new Vector2(-getSpeedNext(10, 40), 0);
                if (i==0)
                    balls[i].Position= new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6*(i+1)-30);
                else if (i==5)
                    balls[i].Position= new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6*(i+1)+30);
                else
                    balls[i].Position= new Vector2(_graphics.PreferredBackBufferWidth-50, _graphics.PreferredBackBufferHeight/6*(i+1));
                balls[i].Enabled=true;
                balls[i].Visible=true;
                balls[i].Speed=ballSpeed;
            }
        }
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }

        public float getSpeedNext(int beginNo, int endNo)
        {
            Random rd = new Random();
            int i = rd.Next(beginNo, endNo);
            return i;
        }
    }
}