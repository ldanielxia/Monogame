﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XiaLi_ShipGame
{
    public class ScoreString : SimpleString
    {
        //private double delay;
        //private double delayCounter;
        private bool flag = true;
        private int score;

        public int Score { get => score; set => score = value; }

        public ScoreString(Game game,
            SpriteBatch spriteBatch,
            SpriteFont font,
            string message,
            Vector2 position,
            Color color,
            int _score) : base(game, spriteBatch, font, message, position, color)
        {
            //this.delay = delay;
            this.Enabled = false;
            this.score = _score;
        }

        public override void Draw(GameTime gameTime)
        {
            if (flag)
            {
                spriteBatch.Begin();
                spriteBatch.DrawString(font, this.Score.ToString() + "  Life", position, color);
                spriteBatch.End();
            }
        }

        public override void Update(GameTime gameTime)
        {
            //if (this.Enabled)
            //{
            //    delayCounter += gameTime.ElapsedGameTime.TotalSeconds;
            //    if (delayCounter >= delay)
            //    {
            //        delayCounter = 0;
            //        this.Enabled = false;
            //    }
            //}

            base.Update(gameTime);
        }
    }
}
